import UIKit

var costo_referencia:[Float] = [8.3,10.5,9.9]

// Funcion Impuesto
func impuesto(col:[Float])->[Float]{
    var returnValue:[Float] = col
    for (index,element) in col.enumerated(){
        print(index)
        print(element)
        returnValue[index] = element + element * 0.16
    }
    
    return returnValue
}
impuesto(col: costo_referencia)

//	Funcion suma 3
let Suma = {(x:Int, y:Int)->Int in return x + y}
Suma(5,5)
func SumaTres(a:Int,b:Int,c:Int)->Int{
    return Suma(a,b) + c
}
SumaTres(a: 2, b: 3, c: 5)

// Funcion generica
func cambio<T>(_ a: inout T, _ b: inout T) {
    let temporaryA = a
    a = b
    b = temporaryA
}
var a = 1
var b = 2
cambio(&a,&b)
a
b

// Funcion transformar
extension Array{
    func transformar<T> (starter:T, functio:(T, Element)->T)->T{
        var res:T = starter
        for valor in self{
            res = functio(res, valor)
        }
        return res
    }
}
var datos1 = [3,7,9,2]
datos1.transformar(starter: 0){(a,b)in a+b}


// var precios con MAP
var precios = [4.2, 5.3, 8.2, 4.5]

let impuesto = precios.map{element in return element + element * 0.16}
impuesto
// filter
var precio_menor = impuesto.filter{ element in element > 6.0}
precio_menor

